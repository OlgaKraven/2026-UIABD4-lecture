import type { Course } from './model';
export declare function LectureSite({ course, base, bundledTeacherNotes }: {
    course: Course;
    base?: string;
    bundledTeacherNotes?: string;
}): import("react").JSX.Element;
