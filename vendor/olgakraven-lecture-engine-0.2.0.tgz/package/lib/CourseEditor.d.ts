import type { Course } from './model';
export default function CourseEditor({ course, base, onClose, }: {
    course: Course;
    base: string;
    onClose: () => void;
}): import("react").JSX.Element;
