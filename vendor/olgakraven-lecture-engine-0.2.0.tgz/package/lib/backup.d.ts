import type { Course } from './model';
export type Backup = {
    schemaVersion: 1;
    kind: 'lecture-backup';
    courseId: string;
    contentVersion: string;
    createdAt: string;
    entries: Record<string, unknown>;
    slides: Record<string, string>;
    tasks: Record<string, string>;
};
export declare function exportBackup(c: Course, base: string, storage: Storage): Backup;
export declare function prepareBackup(value: unknown, c: Course): {
    entries: Record<string, unknown>;
    skipped: number;
    oldVersion: boolean;
};
export declare function applyBackup(entries: Record<string, unknown>, c: Course, base: string, storage: Storage): void;
