import type { Course, Slide } from './model';
export declare function Resources({ course, slide, base }: {
    course: Course;
    slide: Slide;
    base: string;
}): import("react").JSX.Element;
