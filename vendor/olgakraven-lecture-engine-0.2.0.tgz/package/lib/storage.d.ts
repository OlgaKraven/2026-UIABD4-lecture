export declare function read<T>(key: string, fallback: T): T;
export declare function save(key: string, value: unknown): boolean;
export declare function downloadJson(name: string, value: unknown): void;
