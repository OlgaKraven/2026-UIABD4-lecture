import type { ReactNode } from 'react';
export declare function Modal({ title, onClose, children, wide, }: {
    title: string;
    onClose: () => void;
    children: ReactNode;
    wide?: boolean;
}): import("react").JSX.Element;
