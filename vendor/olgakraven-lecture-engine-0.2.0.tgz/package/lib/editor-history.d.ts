export declare function packEditorHistory<T extends object>(history: T): any;
export declare function unpackEditorHistory<T>(stored: T): T;
