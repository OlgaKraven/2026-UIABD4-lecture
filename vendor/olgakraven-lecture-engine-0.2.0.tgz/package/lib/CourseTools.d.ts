import type { Course, Slide } from './model';
export declare function slideText(s: Slide): string;
export declare function StudyButtons({ course, base, slide, }: {
    course: Course;
    base: string;
    slide: Slide;
}): import("react").JSX.Element;
export declare function CourseTools({ course, base, onClose, onGo, }: {
    course: Course;
    base: string;
    onClose: () => void;
    onGo: (lecture: string, slide: string) => void;
}): import("react").JSX.Element;
