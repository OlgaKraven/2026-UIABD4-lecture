import type { Visual } from './model';
export declare function InfographicMobile({ visual: v, base }: {
    visual: Visual;
    base: string;
}): import("react").JSX.Element | null;
