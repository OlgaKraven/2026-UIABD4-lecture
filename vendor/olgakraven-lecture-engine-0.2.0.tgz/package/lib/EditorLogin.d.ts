export declare function EditorLogin({ base, onClose, onLogin, }: {
    base: string;
    onClose: () => void;
    onLogin: () => void;
}): import("react").JSX.Element;
